let count = 2;
function playerCount() {
    a = "<h3>1st Player</h3>";
    b = "<h3>2nd Player</h3>";
    c = "<h3>3rd Player</h3>";
    d = "<h3>" + count + "th Player</h3>";
    
    document.getElementById("border1").innerHTML = a;
    if(document.getElementById("inp").checkValidity()) {
        if(count == 2) document.getElementById("border1").innerHTML = b;
        else if(count == 3) document.getElementById("border1").innerHTML = c;
        else document.getElementById("border1").innerHTML = d;
        count++;
    }
}
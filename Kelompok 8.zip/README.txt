Michael Harry Seriawan (00000055653)
Khesar Kurniawan (00000053491)
Ananda Ayu Putri (00000056361)
Richard Tandean (00000058309)

Peraturan Gameplay

1. Sebelum memulai permainan, semua peserta diharuskan mendaftarkan nama terlebih dahulu

2. Permainan hanya bisa dimainkan dengan paling sedikit 2 orang dan paling banyak 7 orang pemain

3. Jumlah tulang akan mengikuti jumlah pemain, dimana:

    - < 5 pemain banyak tulang adalah 16

    - 6 pemain banyak tulang adalah 20

    - 7 pemain banyak tulang adalah 24

4. Setelah memulai permainan, setiap pemain memiliki waktu 10 detik untuk memilih tulang

5. Ketika waktu habis, maka pemain yang kehabisan waktu otomatis akan kalah

6. Ketika pemain memilih tulang yang membangunkan Spike, maka pemain tersebut kalah

7. Setelah permainan selesai, pemain bisa memilih untuk bermain lagi dengan pemain yang sama atau kembali ke menu utama